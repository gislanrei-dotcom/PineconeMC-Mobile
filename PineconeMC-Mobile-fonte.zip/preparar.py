"""Materializa a base entregue pelo usuário e aplica as alterações locais."""
import argparse
import shutil
import zipfile
from pathlib import Path

commit = b'f5bb1526eb371d81cb086d74cdb8535043b51ee4'
parser = argparse.ArgumentParser()
parser.add_argument('zip_fcl', type=Path)
parser.add_argument('destino', type=Path)
args = parser.parse_args()
target = args.destino.resolve()
with zipfile.ZipFile(args.zip_fcl) as archive:
    if archive.comment != commit:
        parser.error('Use o ZIP do FoldCraftLauncher fornecido nesta conversa.')
    target.mkdir(parents=True, exist_ok=True)
    if any(target.iterdir()):
        parser.error('Selecione um diretório vazio.')
    for entry in archive.infolist():
        rel = Path(entry.filename).relative_to('FoldCraftLauncher-main')
        path = (target / rel).resolve()
        if not path.is_relative_to(target):
            parser.error('Caminho inválido no ZIP.')
        if entry.is_dir():
            path.mkdir(parents=True, exist_ok=True)
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(entry) as src, path.open('wb') as dst:
                shutil.copyfileobj(src, dst)
shutil.copytree(Path(__file__).resolve().parent / 'overlay', target, dirs_exist_ok=True)
(target / 'gradlew').chmod(0o755)
print(target)
